package com.jumpenchant.mod;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import org.slf4j.Logger;
import com.mojang.logging.LogUtils;

/**
 * Главный класс мода "Random Jump Enchant".
 *
 * Логика мода:
 *  - каждый прыжок игрока даёт предмету в главной руке 1 случайное
 *    зачарование случайного (валидного для этого зачарования) уровня.
 *
 * Вся игровая логика находится в {@link PlayerJumpHandler}, который
 * подписан на общую шину событий Forge (MinecraftForge.EVENT_BUS).
 */
@Mod(JumpEnchantMod.MOD_ID)
public class JumpEnchantMod {

    public static final String MOD_ID = "jumpenchant";
    public static final Logger LOGGER = LogUtils.getLogger();

    public JumpEnchantMod() {
        // Регистрируем обработчик игровых событий (серверная шина событий forge).
        MinecraftForge.EVENT_BUS.register(new PlayerJumpHandler());

        LOGGER.info("[JumpEnchant] Мод загружен. Каждый прыжок будет зачаровывать предмет в руке.");
    }
}
