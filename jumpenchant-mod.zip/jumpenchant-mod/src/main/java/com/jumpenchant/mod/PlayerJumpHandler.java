package com.jumpenchant.mod;

import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

/**
 * Обработчик события прыжка живого существа.
 *
 * Forge вызывает {@link LivingEvent.LivingJumpEvent} каждый раз, когда
 * существо отталкивается от земли (прыгает). Мы фильтруем событие так,
 * чтобы реагировать только на игроков, и только на серверной стороне
 * (чтобы не выполнять логику дважды — на клиенте и на сервере).
 */
public class PlayerJumpHandler {

    private static final Random RANDOM = new Random();

    @SubscribeEvent
    public void onLivingJump(LivingEvent.LivingJumpEvent event) {
        // Реагируем только на игроков.
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }

        // Логику зачарования выполняем только на сервере (серверный ServerPlayer),
        // чтобы избежать рассинхронизации клиент/сервер и двойного срабатывания.
        if (!(player instanceof ServerPlayer serverPlayer)) {
            return;
        }

        ItemStack stack = serverPlayer.getMainHandItem();
        if (stack.isEmpty()) {
            // В руке ничего нет — зачаровывать нечего.
            return;
        }

        // Получаем реестр всех зачарований, зарегистрированных в игре
        // (ванильных и добавленных другими модами).
        Registry<Enchantment> enchantmentRegistry =
                serverPlayer.level().registryAccess().registryOrThrow(Registries.ENCHANTMENT);

        List<Holder<Enchantment>> allEnchantments = enchantmentRegistry.holders()
                .collect(Collectors.toList());

        if (allEnchantments.isEmpty()) {
            return;
        }

        // Выбираем абсолютно случайное зачарование из списка (без учёта
        // того, подходит ли оно "по смыслу" для данного предмета).
        Holder<Enchantment> chosenEnchantment = allEnchantments.get(RANDOM.nextInt(allEnchantments.size()));
        Enchantment enchantment = chosenEnchantment.value();

        // Случайный уровень от 1 до максимального для этого зачарования.
        int maxLevel = Math.max(1, enchantment.getMaxLevel());
        int level = 1 + RANDOM.nextInt(maxLevel);

        // Накладываем зачарование на предмет, полностью игнорируя
        // ограничения совместимости предмет/зачарование.
        stack.enchant(chosenEnchantment, level);

        // Звуковой эффект зачарования.
        serverPlayer.level().playSound(
                null,
                serverPlayer.getX(), serverPlayer.getY(), serverPlayer.getZ(),
                SoundEvents.ENCHANTMENT_TABLE_USE,
                SoundSource.PLAYERS,
                1.0F,
                1.0F
        );

        // Сообщение в чат игроку.
        Component enchantmentName = Enchantment.getFullname(chosenEnchantment, level);
        serverPlayer.displayClientMessage(
                Component.literal("§aПрыжок! Предмет получил зачарование: ")
                        .append(enchantmentName),
                true // true = показать над панелью хотбара (action bar), false = обычный чат
        );
    }
}
